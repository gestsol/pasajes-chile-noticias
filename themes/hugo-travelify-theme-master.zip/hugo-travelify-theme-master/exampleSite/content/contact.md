<<<<<<< HEAD
---
title: Contact
date: 2017-06-07T15:36:00+05:30
nodateline: true
noprevnext: true
disable_comments: true

---

# You may contact me through the nearest wormhole

This is where my great contact goes

=======
---
title: Contact
author: nikimonikado
date: 2017-06-07T15:36:00+05:30
nodateline: true
noprevnext: true
disable_comments: true

---

# You may contact me through the nearest wormhole

This is where my great contact goes

>>>>>>> 2bcf044712ef204afed2b77ba27e56a3a9170922
